# Make Your Own Platter (Android)

Android food-ordering app: customers build their own platter within a budget, see the live total, get a budget alert with cheaper swaps, and place an order. The restaurant admin sees each new order live, updates its status, and manages the menu.

Built with Kotlin and Jetpack Compose. Logins use **Firebase Authentication**. Menu, platters, orders and alerts are stored in **Cloud Firestore** (Firebase project `make-your-own-platter-e762d`).

## 1. Firebase console setup (one time)

1. **Authentication:** Build → Authentication → Sign-in method → enable **Email/Password**.
2. **Firestore:** Build → Firestore Database → Create database. Choose any region and start in production mode.
3. **Security rules:** Firestore → Rules → replace the content with `firestore.rules` from this project → **Publish**.
4. **Admin account:** open the app and tap "Create a new account" with the admin's email. Then in Firestore open `users` → that account's document → change `role` from `CUSTOMER` to `ADMIN`.

The starter menu is created the first time an admin logs in.

## 2. Run it in Android Studio

1. Unzip the file and open the `MakeYourOwnPlatter` folder in Android Studio (Koala or newer).
2. Wait for Gradle to sync. The first sync downloads dependencies, so it needs internet.
3. Press **Run** and choose an emulator (Pixel 4, API 30 works) or a phone on Android 7.0 or newer.
4. On Android 13+ allow notifications so order alerts appear.

`app/google-services.json` is already in the project. Keep it there.

## 3. Using the app

- **Customer:** register, log in, enter a budget, add items to the platter, confirm the order.
- **Admin:** log in with the admin account. The dashboard shows incoming orders (update their status), menu management (add or hide items) and order alerts.

## Notes

- Alerts appear in the admin dashboard in real time from any phone. A phone notification pops up while the admin's app is open. Notifications when the app is closed need Firebase Cloud Functions (Blaze plan), which this project does not include.
- Menu pictures are emoji tiles, so no image files are needed.

## How the project maps to the assignment

| Requirement | Where it is |
|---|---|
| Register and secure login | `ui/screens/AuthScreens.kt`, `data/AppRepository.kt` (Firebase Auth) |
| Browse categories, items, images, prices | `ui/screens/MenuScreen.kt`, `data/SeedData.kt` |
| Enter budget (UC-01) | `ui/screens/BudgetScreen.kt` |
| Add/remove items to platter (UC-02) | `ui/screens/MenuScreen.kt`, `viewmodel/AppViewModel.kt` |
| Real-time total, over-budget pop-up, alternatives (UC-03) | `logic/PlatterLogic.kt`, `ui/components/Components.kt` |
| Order summary, confirm or modify (UC-04) | `ui/screens/SummaryScreen.kt` |
| Order saved as PENDING, operator alert | `AppRepository.placeOrder`, `notify/OrderAlertNotifier.kt` |
| Admin dashboard: orders, status, menu, alerts | `ui/screens/AdminScreen.kt` |
| Security rules | `firestore.rules` |

## Project layout

```
app/google-services.json   Firebase project config (keep this file)
firestore.rules            Firestore security rules (paste into the console)
app/src/main/java/com/example/makeyourownplatter/
  MainActivity.kt          entry point, asks for notification permission
  ui/AppNav.kt             screen navigation
  ui/screens/              login, register, budget, menu, summary, admin
  ui/components/           shared cards, quantity buttons, suggestions
  ui/theme/                colours and Material 3 theme
  viewmodel/AppViewModel.kt
  logic/PlatterLogic.kt    budget total and alternative suggestions
  data/                    data classes, Firebase helpers, repository, seed menu
  notify/                  order alert notification
```
