package com.example.makeyourownplatter.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.makeyourownplatter.viewmodel.AppViewModel

/** UC-01 Enter Budget. The budget is locked in before the customer browses the menu. */
@Composable
fun BudgetScreen(
    vm: AppViewModel,
    onContinue: () -> Unit,
    onLogout: () -> Unit
) {
    val user by vm.user.collectAsState()
    val savedBudget by vm.budget.collectAsState()
    var text by remember { mutableStateOf("") }

    // Pre-fill with the budget already saved for the current platter.
    LaunchedEffect(savedBudget) {
        if (text.isEmpty() && savedBudget > 0) text = savedBudget.toString()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Hi ${user?.name ?: "there"}!",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            "How much do you want to spend on your platter?",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
        )

        OutlinedTextField(
            value = text,
            onValueChange = { text = it.filter { c -> c.isDigit() } },
            label = { Text("Budget (Rs.)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
            listOf(500, 1000, 1500).forEach { amount ->
                OutlinedButton(onClick = { text = amount.toString() }) { Text("Rs. $amount") }
            }
        }

        Spacer(Modifier.height(24.dp))
        Button(
            onClick = { vm.saveBudget(text) { onContinue() } },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save budget and browse food") }

        TextButton(onClick = onLogout, modifier = Modifier.padding(top = 8.dp)) {
            Text("Log out")
        }
    }
}
