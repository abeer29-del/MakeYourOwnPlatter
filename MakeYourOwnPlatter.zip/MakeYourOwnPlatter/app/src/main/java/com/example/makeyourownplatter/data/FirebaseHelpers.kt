package com.example.makeyourownplatter.data

import com.google.android.gms.tasks.Task
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Waits for a Firebase Task to finish and returns its result (or throws its error). */
suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { value -> cont.resume(value) }
    addOnFailureListener { error -> cont.resumeWithException(error) }
}

/** Turns one document into an object. A document that can't be read is skipped, not a crash. */
private fun <T> safeMap(doc: DocumentSnapshot, mapper: (DocumentSnapshot) -> T?): T? =
    try {
        mapper(doc)
    } catch (e: Exception) {
        null
    }

/** Live list of documents in a collection. Emits again every time the data changes. */
fun <T> Query.observeList(mapper: (DocumentSnapshot) -> T?): Flow<List<T>> = callbackFlow {
    val registration = addSnapshotListener { snapshot, error ->
        // On a permission or network error we keep the last good list instead of crashing.
        if (error == null && snapshot != null) {
            trySend(snapshot.documents.mapNotNull { safeMap(it, mapper) })
        }
    }
    awaitClose { registration.remove() }
}

/** Live single document. Emits null when the document does not exist. */
fun <T> DocumentReference.observeDoc(mapper: (DocumentSnapshot) -> T?): Flow<T?> = callbackFlow<T?> {
    val registration = addSnapshotListener { snapshot, error ->
        if (error == null && snapshot != null) {
            trySend(if (snapshot.exists()) safeMap(snapshot, mapper) else null)
        }
    }
    awaitClose { registration.remove() }
}
