package com.example.makeyourownplatter.logic

import com.example.makeyourownplatter.data.CartLine
import com.example.makeyourownplatter.data.FoodItemEntity

// Pure budget rules (no Android code), so they are easy to read and test.

data class Suggestion(
    val removeItemId: Long,
    val removeItemName: String,
    val addItemId: Long,
    val addItemName: String,
    val addEmoji: String,
    val addPrice: Int,
    val newTotal: Int,
    val withinBudget: Boolean
)

data class BudgetStatus(
    val total: Int = 0,
    val budget: Int = 0,
    val overBudget: Boolean = false,
    val suggestions: List<Suggestion> = emptyList()
)

object PlatterLogic {

    fun total(lines: List<CartLine>): Int = lines.sumOf { it.price * it.quantity }

    fun status(lines: List<CartLine>, budget: Int, menu: List<FoodItemEntity>): BudgetStatus {
        val total = total(lines)
        val over = budget > 0 && total > budget
        return BudgetStatus(
            total = total,
            budget = budget,
            overBudget = over,
            suggestions = if (over) suggestAlternatives(lines, menu, budget) else emptyList()
        )
    }

    /**
     * For every item in the platter, look for cheaper items in the same category.
     * Swapping one item for a cheaper one gives a new total. Results that bring the
     * total back within budget are listed first, then the cheapest totals.
     */
    fun suggestAlternatives(
        lines: List<CartLine>,
        menu: List<FoodItemEntity>,
        budget: Int
    ): List<Suggestion> {
        val currentTotal = total(lines)
        val suggestions = mutableListOf<Suggestion>()

        for (line in lines) {
            val cheaper = menu.filter {
                it.isAvailable &&
                    it.categoryId == line.categoryId &&
                    it.itemId != line.itemId &&
                    it.price < line.price
            }
            for (alt in cheaper) {
                val newTotal = currentTotal - line.price + alt.price
                suggestions.add(
                    Suggestion(
                        removeItemId = line.itemId,
                        removeItemName = line.name,
                        addItemId = alt.itemId,
                        addItemName = alt.name,
                        addEmoji = alt.emoji,
                        addPrice = alt.price,
                        newTotal = newTotal,
                        withinBudget = newTotal <= budget
                    )
                )
            }
        }

        return suggestions
            .sortedWith(compareByDescending<Suggestion> { it.withinBudget }.thenBy { it.newTotal })
            .take(6)
    }
}

fun formatRs(amount: Int): String = "Rs. $amount"
