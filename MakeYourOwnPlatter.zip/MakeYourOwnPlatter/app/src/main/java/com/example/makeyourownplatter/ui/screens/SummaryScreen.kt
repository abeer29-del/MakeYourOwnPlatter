package com.example.makeyourownplatter.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.makeyourownplatter.logic.PlatterLogic
import com.example.makeyourownplatter.logic.formatRs
import com.example.makeyourownplatter.ui.components.BudgetCard
import com.example.makeyourownplatter.viewmodel.AppViewModel

/** UC-04 Place Order: review the selected items, then confirm or modify. */
@Composable
fun SummaryScreen(
    vm: AppViewModel,
    onModify: () -> Unit,
    onPlaced: (Long) -> Unit
) {
    val cart by vm.cart.collectAsState()
    val budget by vm.budget.collectAsState()
    val total = PlatterLogic.total(cart)
    var askConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            "Order summary",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(12.dp))
        BudgetCard(total = total, budget = budget)
        Spacer(Modifier.height(16.dp))

        if (cart.isEmpty()) {
            Text("Your platter is empty. Go back and add some items.")
        } else {
            cart.forEach { line ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("${line.quantity} x ${line.name}")
                    Text(formatRs(line.price * line.quantity), fontWeight = FontWeight.SemiBold)
                }
                HorizontalDivider()
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Total", fontWeight = FontWeight.Bold)
                Text(formatRs(total), fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(24.dp))
        Button(
            onClick = { askConfirm = true },
            enabled = cart.isNotEmpty(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Confirm order") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onModify, modifier = Modifier.fillMaxWidth()) {
            Text("Modify platter")
        }
    }

    if (askConfirm) {
        AlertDialog(
            onDismissRequest = { askConfirm = false },
            title = { Text("Place this order?") },
            text = { Text("Total ${formatRs(total)}. The restaurant will be alerted to prepare it.") },
            confirmButton = {
                TextButton(onClick = {
                    askConfirm = false
                    vm.placeOrder(onPlaced)
                }) { Text("Yes, place order") }
            },
            dismissButton = {
                TextButton(onClick = { askConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

/** Shown after the order is saved in the database with status PENDING. */
@Composable
fun PlacedScreen(
    orderId: Long,
    onNewPlatter: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("✅", style = MaterialTheme.typography.displayMedium)
        Text(
            "Order placed!",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Order #$orderId is saved with status PENDING. The restaurant has been alerted.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(vertical = 12.dp)
        )
        Button(onClick = onNewPlatter, modifier = Modifier.fillMaxWidth()) {
            Text("Build a new platter")
        }
    }
}
