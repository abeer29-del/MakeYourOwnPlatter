package com.example.makeyourownplatter.data

// Plain data classes used by the screens. The data itself lives in Cloud Firestore
// (see AppRepository). Ids are numbers so the rest of the app works with Long values.

data class UserEntity(
    val userId: Long = 0,
    val uid: String = "",            // Firebase Authentication user id
    val name: String = "",
    val email: String = "",
    val budgetLimit: Int = 0,
    val role: String = "CUSTOMER"    // CUSTOMER or ADMIN
)

data class CategoryEntity(
    val categoryId: Long = 0,
    val name: String = ""
)

data class FoodItemEntity(
    val itemId: Long = 0,
    val categoryId: Long = 0,
    val name: String = "",
    val description: String = "",
    val price: Int = 0,
    val emoji: String = "",
    val isAvailable: Boolean = true
)

data class PlatterEntity(
    val platterId: Long = 0,
    val userId: Long = 0,
    val ownerUid: String = "",
    val currentBudget: Int = 0,
    val status: String = "ACTIVE"    // ACTIVE while being built, ORDERED after checkout
)

data class PlatterItemEntity(
    val platterId: Long,
    val itemId: Long,
    val quantity: Int
)

data class OrderItemEntity(
    val orderId: Long,
    val itemId: Long,
    val itemName: String,
    val unitPrice: Int,
    val quantity: Int
)

data class OrderEntity(
    val orderId: Long = 0,
    val userId: Long = 0,
    val customerName: String = "",
    val customerEmail: String = "",
    val platterId: Long = 0,
    val budget: Int = 0,
    val totalAmount: Int = 0,
    val orderStatus: String = "PENDING",   // PENDING, PREPARING, READY, COMPLETED
    val orderDate: Long = 0,
    val items: List<OrderItemEntity> = emptyList()
)

data class AlertEntity(
    val alertId: Long = 0,
    val orderId: Long = 0,
    val message: String = "",
    val timestamp: Long = 0,
    val isRead: Boolean = false
)

/** One line of the platter as shown to the customer (item joined with its menu details). */
data class CartLine(
    val itemId: Long,
    val name: String,
    val price: Int,
    val emoji: String,
    val categoryId: Long,
    val quantity: Int
)

/** One row of the admin orders list. */
data class OrderRow(
    val orderId: Long,
    val customerName: String,
    val customerEmail: String,
    val budget: Int,
    val totalAmount: Int,
    val orderStatus: String,
    val orderDate: Long
)
