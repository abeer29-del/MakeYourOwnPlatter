package com.example.makeyourownplatter.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.makeyourownplatter.logic.Suggestion
import com.example.makeyourownplatter.logic.formatRs

/** Picture tile for a menu item (emoji based, so no image files are needed). */
@Composable
fun EmojiTile(emoji: String, size: Dp = 64.dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Text(text = emoji, fontSize = (size.value * 0.45f).sp)
    }
}

/** Shows the running total against the budget. Turns red when over budget. */
@Composable
fun BudgetCard(total: Int, budget: Int, modifier: Modifier = Modifier) {
    val overBudget = budget > 0 && total > budget
    val container = if (overBudget) MaterialTheme.colorScheme.errorContainer
    else MaterialTheme.colorScheme.secondaryContainer
    val content = if (overBudget) MaterialTheme.colorScheme.onErrorContainer
    else MaterialTheme.colorScheme.onSecondaryContainer

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = container)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Platter total", style = MaterialTheme.typography.labelLarge, color = content)
            Text(
                formatRs(total),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = content
            )
            Text(
                if (budget > 0) "Budget ${formatRs(budget)}" else "No budget set yet",
                style = MaterialTheme.typography.bodyMedium,
                color = content
            )
            if (budget > 0) {
                Text(
                    if (overBudget) "Over budget by ${formatRs(total - budget)}"
                    else "${formatRs(budget - total)} left to spend",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = content
                )
            }
        }
    }
}

/** One cheaper-alternative suggestion with a button to apply it. */
@Composable
fun SuggestionRow(suggestion: Suggestion, onApply: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            EmojiTile(suggestion.addEmoji, size = 44.dp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Swap ${suggestion.removeItemName} for", style = MaterialTheme.typography.bodySmall)
                Text(
                    "${suggestion.addItemName} (${formatRs(suggestion.addPrice)})",
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    if (suggestion.withinBudget) "Brings total to ${formatRs(suggestion.newTotal)} - within budget"
                    else "Total would be ${formatRs(suggestion.newTotal)} - still over budget",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (suggestion.withinBudget) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error
                )
            }
            Spacer(Modifier.width(8.dp))
            Button(onClick = onApply) { Text("Swap") }
        }
    }
}

/** Small round-ish +/- control used on items and in the platter. */
@Composable
fun QuantityControl(quantity: Int, onMinus: () -> Unit, onPlus: () -> Unit, enabled: Boolean = true) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(
            onClick = onMinus,
            enabled = enabled && quantity > 0,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
            modifier = Modifier.size(40.dp)
        ) { Text("-", fontWeight = FontWeight.Bold) }
        Text(
            quantity.toString(),
            modifier = Modifier.padding(horizontal = 12.dp),
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium
        )
        Button(
            onClick = onPlus,
            enabled = enabled,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
            modifier = Modifier.size(40.dp)
        ) { Text("+", fontWeight = FontWeight.Bold) }
    }
}

/** Consistent section title. */
@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
    )
}

/** Keeps a label + value pair on one line (used in admin cards). */
@Composable
fun LabelValue(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}
