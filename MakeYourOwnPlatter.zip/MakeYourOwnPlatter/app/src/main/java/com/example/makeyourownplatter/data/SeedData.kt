package com.example.makeyourownplatter.data

// Starter menu inserted the first time the app runs. Prices are in Rs.
// The admin can add, edit, or hide items from the Menu tab.

data class SeedItem(
    val name: String,
    val description: String,
    val price: Int,
    val emoji: String
)

object SeedData {
    val menu: List<Pair<String, List<SeedItem>>> = listOf(
        "Pizza" to listOf(
            SeedItem("Margherita", "Tomato, mozzarella and fresh basil", 650, "🍕"),
            SeedItem("Pepperoni", "Pepperoni slices with extra cheese", 850, "🍕"),
            SeedItem("Veggie Supreme", "Peppers, onion, olives and corn", 750, "🍕"),
            SeedItem("Chicken Tikka Pizza", "Tikka chicken with green chillies", 900, "🍕")
        ),
        "Pasta" to listOf(
            SeedItem("Chicken Alfredo", "Creamy alfredo sauce with grilled chicken", 600, "🍝"),
            SeedItem("Arrabbiata", "Spicy tomato sauce with garlic", 500, "🍝"),
            SeedItem("Pesto Pasta", "Basil pesto with parmesan", 550, "🍝")
        ),
        "Burgers" to listOf(
            SeedItem("Classic Beef Burger", "Beef patty, lettuce, tomato and cheese", 350, "🍔"),
            SeedItem("Chicken Burger", "Crispy chicken fillet with mayo", 300, "🍔"),
            SeedItem("Zinger Burger", "Spicy fried chicken with sauce", 400, "🍔"),
            SeedItem("Veggie Burger", "Crispy veggie patty with salad", 280, "🍔")
        ),
        "Sandwiches" to listOf(
            SeedItem("Club Sandwich", "Chicken, egg and bacon on toast", 380, "🥪"),
            SeedItem("Grilled Chicken Sandwich", "Grilled chicken with cheese", 320, "🥪"),
            SeedItem("Egg Sandwich", "Boiled egg with mayo and salad", 200, "🥪")
        ),
        "Drinks" to listOf(
            SeedItem("Cold Drink", "Chilled 500 ml bottle", 120, "🥤"),
            SeedItem("Fresh Lemonade", "Fresh lime and mint", 150, "🍋"),
            SeedItem("Iced Coffee", "Cold coffee with milk", 250, "☕"),
            SeedItem("Mango Shake", "Thick mango milkshake", 220, "🥭")
        ),
        "Desserts" to listOf(
            SeedItem("Chocolate Brownie", "Warm brownie with chocolate chips", 180, "🍫"),
            SeedItem("Ice Cream Scoop", "Vanilla or chocolate scoop", 150, "🍨"),
            SeedItem("Cheesecake Slice", "Baked cheesecake with berry sauce", 330, "🍰")
        )
    )
}
