package com.example.makeyourownplatter.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppColors = lightColorScheme(
    primary = Color(0xFFE65100),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE0CC),
    onPrimaryContainer = Color(0xFF3E1A00),
    secondary = Color(0xFF2E7D32),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCDEFD0),
    onSecondaryContainer = Color(0xFF0B3A10),
    background = Color(0xFFFFF8F0),
    onBackground = Color(0xFF211A14),
    surface = Color.White,
    onSurface = Color(0xFF211A14),
    surfaceVariant = Color(0xFFF3E9DF),
    onSurfaceVariant = Color(0xFF52443A),
    error = Color(0xFFB3261E),
    onError = Color.White,
    errorContainer = Color(0xFFF9DEDC),
    onErrorContainer = Color(0xFF410E0B)
)

@Composable
fun MakeYourOwnPlatterTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AppColors, content = content)
}
