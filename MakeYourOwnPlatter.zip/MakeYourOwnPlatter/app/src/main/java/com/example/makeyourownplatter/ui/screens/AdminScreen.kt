package com.example.makeyourownplatter.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.makeyourownplatter.data.AlertEntity
import com.example.makeyourownplatter.data.CategoryEntity
import com.example.makeyourownplatter.data.FoodItemEntity
import com.example.makeyourownplatter.data.OrderItemEntity
import com.example.makeyourownplatter.data.OrderRow
import com.example.makeyourownplatter.logic.formatRs
import com.example.makeyourownplatter.ui.components.EmojiTile
import com.example.makeyourownplatter.ui.components.LabelValue
import com.example.makeyourownplatter.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val ORDER_STATUSES = listOf("PENDING", "PREPARING", "READY", "COMPLETED")

private fun formatDate(millis: Long): String =
    SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(millis))

/** Admin dashboard: view incoming orders, update status, manage menu, read alerts. */
@Composable
fun AdminScreen(
    vm: AppViewModel,
    onLogout: () -> Unit
) {
    val orders by vm.orderRows.collectAsState()
    val orderItems by vm.orderItems.collectAsState()
    val alerts by vm.alerts.collectAsState()
    val unread by vm.unreadAlerts.collectAsState()
    val orderCount by vm.orderCount.collectAsState()
    val revenue by vm.revenue.collectAsState()
    val categories by vm.categories.collectAsState()
    val menuItems by vm.allItems.collectAsState()

    var tab by remember { mutableStateOf(0) }
    val titles = listOf("Orders", "Menu", "Alerts ($unread)")

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Admin dashboard",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onLogout) { Text("Log out") }
        }
        Text(
            "Orders: $orderCount    Revenue: ${formatRs(revenue)}",
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        TabRow(selectedTabIndex = tab) {
            titles.forEachIndexed { index, title ->
                Tab(
                    selected = tab == index,
                    onClick = { tab = index },
                    text = { Text(title) }
                )
            }
        }

        when (tab) {
            0 -> OrdersTab(
                modifier = Modifier.weight(1f),
                orders = orders,
                orderItems = orderItems,
                onStatus = { orderId, status -> vm.setOrderStatus(orderId, status) }
            )
            1 -> MenuTab(
                modifier = Modifier.weight(1f),
                vm = vm,
                categories = categories,
                menuItems = menuItems
            )
            else -> AlertsTab(
                modifier = Modifier.weight(1f),
                alerts = alerts,
                onRead = { vm.markAlertRead(it) },
                onReadAll = { vm.markAllAlertsRead() }
            )
        }
    }
}

@Composable
private fun OrdersTab(
    modifier: Modifier,
    orders: List<OrderRow>,
    orderItems: Map<Long, List<OrderItemEntity>>,
    onStatus: (Long, String) -> Unit
) {
    if (orders.isEmpty()) {
        Text(
            "No orders yet. Place an order from the customer side to see it here.",
            modifier = modifier.padding(16.dp)
        )
        return
    }
    LazyColumn(
        modifier = modifier.padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(orders, key = { it.orderId }) { order ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        "Order #${order.orderId} - ${order.customerName}",
                        fontWeight = FontWeight.Bold
                    )
                    LabelValue("Email", order.customerEmail)
                    LabelValue("Placed", formatDate(order.orderDate))
                    LabelValue("Budget", formatRs(order.budget))
                    LabelValue("Total", formatRs(order.totalAmount))
                    LabelValue("Status", order.orderStatus)
                    (orderItems[order.orderId] ?: emptyList()).forEach { line ->
                        Text(
                            "${line.quantity} x ${line.itemName} (${formatRs(line.unitPrice)})",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        ORDER_STATUSES.forEach { status ->
                            if (status == order.orderStatus) {
                                Button(
                                    onClick = { onStatus(order.orderId, status) },
                                    contentPadding = PaddingValues(horizontal = 2.dp),
                                    modifier = Modifier.weight(1f)
                                ) { Text(status, style = MaterialTheme.typography.labelSmall) }
                            } else {
                                OutlinedButton(
                                    onClick = { onStatus(order.orderId, status) },
                                    contentPadding = PaddingValues(horizontal = 2.dp),
                                    modifier = Modifier.weight(1f)
                                ) { Text(status, style = MaterialTheme.typography.labelSmall) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuTab(
    modifier: Modifier,
    vm: AppViewModel,
    categories: List<CategoryEntity>,
    menuItems: List<FoodItemEntity>
) {
    var chosenCategoryId by remember { mutableStateOf<Long?>(null) }
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var emoji by remember { mutableStateOf("") }
    val selectedCategoryId = chosenCategoryId ?: categories.firstOrNull()?.categoryId

    LazyColumn(
        modifier = modifier.padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Add a new menu item (UC-06 "Add New Component")
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Add a menu item", fontWeight = FontWeight.Bold)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(vertical = 6.dp)
                    ) {
                        items(categories, key = { it.categoryId }) { category ->
                            FilterChip(
                                selected = category.categoryId == selectedCategoryId,
                                onClick = { chosenCategoryId = category.categoryId },
                                label = { Text(category.name) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Item name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = price,
                            onValueChange = { price = it.filter { c -> c.isDigit() } },
                            label = { Text("Price (Rs.)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        OutlinedTextField(
                            value = emoji,
                            onValueChange = { emoji = it },
                            label = { Text("Emoji") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Button(
                        onClick = {
                            val catId = selectedCategoryId ?: return@Button
                            vm.addMenuItem(
                                categoryId = catId,
                                name = name,
                                description = description,
                                priceText = price,
                                emoji = emoji.ifBlank { "🍽️" },
                                onDone = {
                                    name = ""
                                    description = ""
                                    price = ""
                                    emoji = ""
                                }
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    ) { Text("Add to menu") }
                }
            }
        }

        // Existing items: show/hide them from customers
        items(menuItems, key = { it.itemId }) { item ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    EmojiTile(item.emoji, size = 44.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.name, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${categories.firstOrNull { it.categoryId == item.categoryId }?.name ?: ""} - ${formatRs(item.price)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    OutlinedButton(
                        onClick = { vm.updateMenuItem(item.copy(isAvailable = !item.isAvailable)) }
                    ) { Text(if (item.isAvailable) "Hide" else "Show") }
                }
            }
        }
    }
}

@Composable
private fun AlertsTab(
    modifier: Modifier,
    alerts: List<AlertEntity>,
    onRead: (Long) -> Unit,
    onReadAll: () -> Unit
) {
    Column(modifier = modifier.padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("New order alerts", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onReadAll) { Text("Mark all read") }
        }
        if (alerts.isEmpty()) {
            Text("No alerts yet. A new alert appears each time a customer places an order.")
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(alerts, key = { it.alertId }) { alert ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                alert.message,
                                fontWeight = if (alert.isRead) FontWeight.Normal else FontWeight.Bold
                            )
                            Text(
                                formatDate(alert.timestamp),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        if (alert.isRead) {
                            Text("Read", style = MaterialTheme.typography.bodySmall)
                        } else {
                            Button(onClick = { onRead(alert.alertId) }) { Text("Mark read") }
                        }
                    }
                }
            }
        }
    }
}
