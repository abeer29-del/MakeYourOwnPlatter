package com.example.makeyourownplatter.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.makeyourownplatter.data.CategoryEntity
import com.example.makeyourownplatter.data.FoodItemEntity
import com.example.makeyourownplatter.logic.formatRs
import com.example.makeyourownplatter.ui.components.BudgetCard
import com.example.makeyourownplatter.ui.components.EmojiTile
import com.example.makeyourownplatter.ui.components.QuantityControl
import com.example.makeyourownplatter.ui.components.SuggestionRow
import com.example.makeyourownplatter.viewmodel.AppViewModel

/**
 * UC-02 Add/Remove items, UC-03 Budget Management.
 * Browse categories, add or remove items, see the running total, and get
 * a pop-up plus cheaper alternatives the moment the budget is exceeded.
 */
@Composable
fun MenuScreen(
    vm: AppViewModel,
    onViewSummary: () -> Unit,
    onChangeBudget: () -> Unit,
    onLogout: () -> Unit
) {
    val categories by vm.categories.collectAsState()
    val menuItems by vm.allItems.collectAsState()
    val cart by vm.cart.collectAsState()
    val status by vm.budgetStatus.collectAsState()
    val showPopup by vm.overBudgetPopup.collectAsState()

    var selectedCategoryId by remember { mutableStateOf<Long?>(null) }
    val currentCategory: CategoryEntity? =
        categories.firstOrNull { it.categoryId == selectedCategoryId } ?: categories.firstOrNull()
    val shownItems = menuItems.filter { it.categoryId == currentCategory?.categoryId && it.isAvailable }
    val itemCount = cart.sumOf { it.quantity }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text(
                "Build your platter",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onChangeBudget) { Text("Budget") }
            TextButton(onClick = onLogout) { Text("Log out") }
        }

        BudgetCard(total = status.total, budget = status.budget)

        // UC-03: when over budget, show cheaper alternatives under the warning.
        if (status.overBudget) {
            Text(
                "Over budget! Tap Swap to bring your total back within budget.",
                color = MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 8.dp)
            )
            if (status.suggestions.isEmpty()) {
                Text(
                    "No cheaper items in these categories. Increase your budget or remove items.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp)
                )
            } else {
                Column(modifier = Modifier.padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    status.suggestions.take(3).forEach { s ->
                        SuggestionRow(s) { vm.swapItem(s.removeItemId, s.addItemId) }
                    }
                }
            }
        }

        // Category tabs
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(vertical = 12.dp)
        ) {
            items(categories, key = { it.categoryId }) { category ->
                FilterChip(
                    selected = category.categoryId == currentCategory?.categoryId,
                    onClick = { selectedCategoryId = category.categoryId },
                    label = { Text(category.name) }
                )
            }
        }

        // Food items with picture, description and price
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(shownItems, key = { it.itemId }) { item ->
                MenuItemRow(
                    item = item,
                    quantity = cart.firstOrNull { it.itemId == item.itemId }?.quantity ?: 0,
                    onAdd = { vm.addItem(item.itemId) },
                    onRemove = { vm.removeItem(item.itemId) }
                )
            }
        }

        Spacer(Modifier.height(8.dp))
        Button(
            onClick = onViewSummary,
            enabled = itemCount > 0,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (itemCount > 0) "View order summary ($itemCount items)" else "Add items to continue")
        }
    }

    // Pop-up shown the moment a choice pushes the platter over budget.
    if (showPopup) {
        AlertDialog(
            onDismissRequest = { vm.dismissOverBudgetPopup() },
            title = { Text("Budget exceeded") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text("Your platter is ${formatRs(status.total)}, which is above your budget of ${formatRs(status.budget)}.")
                    if (status.suggestions.isNotEmpty()) {
                        Text("Try one of these swaps:", modifier = Modifier.padding(top = 8.dp))
                        Column(
                            modifier = Modifier.padding(top = 6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            status.suggestions.forEach { s ->
                                SuggestionRow(s) { vm.swapItem(s.removeItemId, s.addItemId) }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.dismissOverBudgetPopup() }) { Text("OK") }
            }
        )
    }
}

@Composable
private fun MenuItemRow(
    item: FoodItemEntity,
    quantity: Int,
    onAdd: () -> Unit,
    onRemove: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            EmojiTile(item.emoji, size = 64.dp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(item.name, fontWeight = FontWeight.Bold)
                Text(
                    item.description,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    formatRs(item.price),
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            QuantityControl(quantity = quantity, onMinus = onRemove, onPlus = onAdd)
        }
    }
}
