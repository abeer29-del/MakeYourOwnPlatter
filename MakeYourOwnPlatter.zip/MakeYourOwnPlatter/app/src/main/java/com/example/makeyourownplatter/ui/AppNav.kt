package com.example.makeyourownplatter.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.makeyourownplatter.ui.screens.AdminScreen
import com.example.makeyourownplatter.ui.screens.BudgetScreen
import com.example.makeyourownplatter.ui.screens.LoginScreen
import com.example.makeyourownplatter.ui.screens.MenuScreen
import com.example.makeyourownplatter.ui.screens.PlacedScreen
import com.example.makeyourownplatter.ui.screens.RegisterScreen
import com.example.makeyourownplatter.ui.screens.SummaryScreen
import com.example.makeyourownplatter.viewmodel.AppViewModel

object Routes {
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val BUDGET = "budget"        // UC-01 Enter Budget
    const val MENU = "menu"            // UC-02 / UC-03 Browse, add/remove, budget tracking
    const val SUMMARY = "summary"      // UC-04 Order summary + Confirm
    const val PLACED = "placed/{orderId}"
    const val ADMIN = "admin"          // Admin dashboard
}

/** Clears the back stack and opens [route]. */
private fun NavHostController.openAndClear(route: String) {
    navigate(route) {
        popUpTo(graph.id) { inclusive = true }
    }
}

@Composable
fun AppRoot() {
    val vm: AppViewModel = viewModel()
    val navController = rememberNavController()
    val snackbarHost = remember { SnackbarHostState() }

    // Validation and login messages from the ViewModel appear as snackbars.
    LaunchedEffect(Unit) {
        vm.messages.collect { snackbarHost.showSnackbar(it) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHost) }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.LOGIN,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            composable(Routes.LOGIN) {
                LoginScreen(
                    vm = vm,
                    onLoggedIn = { isAdmin ->
                        navController.openAndClear(if (isAdmin) Routes.ADMIN else Routes.BUDGET)
                    },
                    onRegister = { navController.navigate(Routes.REGISTER) }
                )
            }

            composable(Routes.REGISTER) {
                RegisterScreen(
                    vm = vm,
                    onRegistered = { navController.openAndClear(Routes.BUDGET) },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.BUDGET) {
                BudgetScreen(
                    vm = vm,
                    onContinue = { navController.navigate(Routes.MENU) },
                    onLogout = {
                        vm.logout()
                        navController.openAndClear(Routes.LOGIN)
                    }
                )
            }

            composable(Routes.MENU) {
                MenuScreen(
                    vm = vm,
                    onViewSummary = { navController.navigate(Routes.SUMMARY) },
                    onChangeBudget = { navController.popBackStack() },
                    onLogout = {
                        vm.logout()
                        navController.openAndClear(Routes.LOGIN)
                    }
                )
            }

            composable(Routes.SUMMARY) {
                SummaryScreen(
                    vm = vm,
                    onModify = { navController.popBackStack() },
                    onPlaced = { orderId -> navController.openAndClear("placed/$orderId") }
                )
            }

            composable(
                route = Routes.PLACED,
                arguments = listOf(navArgument("orderId") { type = NavType.LongType })
            ) { entry ->
                PlacedScreen(
                    orderId = entry.arguments?.getLong("orderId") ?: 0L,
                    onNewPlatter = { navController.openAndClear(Routes.BUDGET) }
                )
            }

            composable(Routes.ADMIN) {
                AdminScreen(
                    vm = vm,
                    onLogout = {
                        vm.logout()
                        navController.openAndClear(Routes.LOGIN)
                    }
                )
            }
        }
    }
}
