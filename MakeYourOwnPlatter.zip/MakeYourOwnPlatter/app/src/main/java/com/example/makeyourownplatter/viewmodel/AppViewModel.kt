package com.example.makeyourownplatter.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.makeyourownplatter.data.AlertEntity
import com.example.makeyourownplatter.data.AppRepository
import com.example.makeyourownplatter.data.CartLine
import com.example.makeyourownplatter.data.CategoryEntity
import com.example.makeyourownplatter.data.FoodItemEntity
import com.example.makeyourownplatter.data.OrderEntity
import com.example.makeyourownplatter.data.OrderItemEntity
import com.example.makeyourownplatter.data.OrderRow
import com.example.makeyourownplatter.data.PlatterEntity
import com.example.makeyourownplatter.data.UserEntity
import com.example.makeyourownplatter.logic.BudgetStatus
import com.example.makeyourownplatter.logic.PlatterLogic
import com.example.makeyourownplatter.notify.OrderAlertNotifier
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

// One shared ViewModel for the whole app: the logged-in user, the active platter,
// and the data each screen shows. Data comes live from Cloud Firestore.
class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AppRepository()

    // ----- Session: the logged-in customer or admin (null when signed out) -----
    private val _session = MutableStateFlow<UserEntity?>(null)
    val user: StateFlow<UserEntity?> = _session.asStateFlow()

    val isAdmin: StateFlow<Boolean> = _session
        .map { it?.role == "ADMIN" }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    // ----- Messages for snackbars -----
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages = _messages.asSharedFlow()

    // ----- Menu (read only while someone is logged in, as Firestore rules require) -----
    val categories: StateFlow<List<CategoryEntity>> = _session
        .flatMapLatest { session ->
            if (session == null) flowOf(emptyList<CategoryEntity>()) else repo.observeCategories()
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val allItems: StateFlow<List<FoodItemEntity>> = _session
        .flatMapLatest { session ->
            if (session == null) flowOf(emptyList<FoodItemEntity>()) else repo.observeAllItems()
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ----- Active platter (budget + cart) -----
    private val _platterId = MutableStateFlow<Long?>(null)

    val cart: StateFlow<List<CartLine>> = _platterId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList<CartLine>()) else repo.observeCart(id)
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val budget: StateFlow<Int> = _platterId
        .flatMapLatest { id ->
            if (id == null) flowOf<PlatterEntity?>(null) else repo.observePlatter(id)
        }
        .map { it?.currentBudget ?: 0 }
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val budgetStatus: StateFlow<BudgetStatus> = combine(cart, budget, allItems) { lines, b, items ->
        PlatterLogic.status(lines, b, items)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, BudgetStatus())

    // Pop-up shown the moment a choice pushes the platter over budget.
    private val _overBudgetPopup = MutableStateFlow(false)
    val overBudgetPopup: StateFlow<Boolean> = _overBudgetPopup.asStateFlow()

    fun dismissOverBudgetPopup() {
        _overBudgetPopup.value = false
    }

    // ----- Admin data (only read while an admin is logged in) -----
    private val adminOrders: StateFlow<List<OrderEntity>> = _session
        .flatMapLatest { session ->
            if (session?.role == "ADMIN") repo.observeOrders() else flowOf(emptyList<OrderEntity>())
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val orderRows: StateFlow<List<OrderRow>> = adminOrders
        .map { orders ->
            orders.map { o ->
                OrderRow(
                    orderId = o.orderId,
                    customerName = o.customerName,
                    customerEmail = o.customerEmail,
                    budget = o.budget,
                    totalAmount = o.totalAmount,
                    orderStatus = o.orderStatus,
                    orderDate = o.orderDate
                )
            }
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val orderItems: StateFlow<Map<Long, List<OrderItemEntity>>> = adminOrders
        .map { orders -> orders.associate { it.orderId to it.items } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val alerts: StateFlow<List<AlertEntity>> = _session
        .flatMapLatest { session ->
            if (session?.role == "ADMIN") repo.observeAlerts() else flowOf(emptyList<AlertEntity>())
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val unreadAlerts: StateFlow<Int> = alerts
        .map { list -> list.count { !it.isRead } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val orderCount: StateFlow<Int> = adminOrders
        .map { it.size }
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val revenue: StateFlow<Int> = adminOrders
        .map { orders -> orders.filter { it.orderStatus != "CANCELLED" }.sumOf { it.totalAmount } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    // While an admin is logged in, a new alert from any phone shows a notification here.
    private var alertWatch: Job? = null

    private fun watchNewOrderAlerts() {
        alertWatch?.cancel()
        alertWatch = viewModelScope.launch {
            val seen = HashSet<Long>()
            var firstLoad = true
            repo.observeAlerts().collect { list ->
                if (firstLoad) {
                    // Existing alerts are not announced again when the admin logs in.
                    seen.addAll(list.map { it.alertId })
                    firstLoad = false
                } else {
                    list.filter { !it.isRead && seen.add(it.alertId) }.forEach { alert ->
                        OrderAlertNotifier.notifyAlert(getApplication(), alert)
                    }
                }
            }
        }
    }

    // ===== Account =====

    fun register(name: String, email: String, password: String, onSuccess: () -> Unit) {
        launchSafely {
            val user = repo.register(name, email, password).getOrThrow()
            startSession(user)
            onSuccess()
        }
    }

    /** Calls onSuccess with true when the account is an admin, false for a customer. */
    fun login(email: String, password: String, onSuccess: (Boolean) -> Unit) {
        launchSafely {
            val user = repo.login(email, password).getOrThrow()
            startSession(user)
            onSuccess(user.role == "ADMIN")
        }
    }

    private suspend fun startSession(user: UserEntity) {
        _session.value = user
        if (user.role == "ADMIN") {
            repo.seedMenuIfEmpty()      // creates the starter menu the first time
            _platterId.value = null
            watchNewOrderAlerts()
        } else {
            _platterId.value = repo.getOrCreateActivePlatter(user).platterId
        }
    }

    fun logout() {
        alertWatch?.cancel()
        repo.signOut()
        _session.value = null
        _platterId.value = null
        _overBudgetPopup.value = false
    }

    // ===== Budget (UC-01) =====

    fun saveBudget(amountText: String, onSaved: () -> Unit) {
        val amount = amountText.trim().toIntOrNull()
        if (amount == null || amount <= 0) {
            say("Please enter a valid positive budget amount.")
            return
        }
        val user = _session.value ?: return
        launchSafely {
            _platterId.value = repo.setBudget(user, amount)
            onSaved()
        }
    }

    // ===== Platter (UC-02, UC-03) =====

    fun addItem(itemId: Long) = changeQuantity(itemId, +1)

    fun removeItem(itemId: Long) = changeQuantity(itemId, -1)

    private fun changeQuantity(itemId: Long, delta: Int) {
        val platterId = _platterId.value ?: return
        launchSafely {
            val wasOver = budgetStatus.value.overBudget
            repo.changeQuantity(platterId, itemId, delta)
            val currentBudget = budget.value
            val lines = repo.currentCart(platterId)
            val nowOver = currentBudget > 0 && PlatterLogic.total(lines) > currentBudget
            if (delta > 0 && !wasOver && nowOver) {
                _overBudgetPopup.value = true
            }
        }
    }

    /** Replace an item with a cheaper one, as suggested in the budget alert. */
    fun swapItem(removeItemId: Long, addItemId: Long) {
        val platterId = _platterId.value ?: return
        launchSafely {
            repo.swapItems(platterId, removeItemId, addItemId)
            _overBudgetPopup.value = false
        }
    }

    // ===== Order placement (UC-04) =====

    fun placeOrder(onPlaced: (Long) -> Unit) {
        val user = _session.value ?: return
        val platterId = _platterId.value ?: return
        launchSafely {
            val orderId = repo.placeOrder(user, platterId).getOrThrow()
            // Start a fresh platter for the next order.
            _platterId.value = repo.getOrCreateActivePlatter(user).platterId
            onPlaced(orderId)
        }
    }

    // ===== Admin actions =====

    fun setOrderStatus(orderId: Long, status: String) {
        launchSafely { repo.setOrderStatus(orderId, status) }
    }

    fun addMenuItem(
        categoryId: Long,
        name: String,
        description: String,
        priceText: String,
        emoji: String,
        onDone: () -> Unit
    ) {
        val price = priceText.trim().toIntOrNull()
        if (price == null) {
            say("Price must be a whole number.")
            return
        }
        launchSafely {
            repo.addMenuItem(categoryId, name, description, price, emoji)
            onDone()
            say("Item added to the menu.")
        }
    }

    fun updateMenuItem(item: FoodItemEntity) {
        launchSafely { repo.updateMenuItem(item) }
    }

    fun markAlertRead(alertId: Long) {
        launchSafely { repo.markAlertRead(alertId) }
    }

    fun markAllAlertsRead() {
        launchSafely { repo.markAllAlertsRead() }
    }

    // ===== helpers =====

    /** Runs an action in the background; any error becomes a snackbar message instead of a crash. */
    private fun launchSafely(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                say(e.friendly())
            }
        }
    }

    private fun say(message: String) {
        _messages.tryEmit(message)
    }
}

private fun Throwable.friendly(): String = when (this) {
    is FirebaseAuthInvalidCredentialsException -> "Wrong email or password."
    is FirebaseAuthInvalidUserException -> "No account found for this email. Please register first."
    is FirebaseAuthUserCollisionException -> "An account with this email already exists."
    is FirebaseAuthWeakPasswordException -> "Password is too weak. Use at least 6 characters."
    else -> message ?: "Something went wrong. Please try again."
}
