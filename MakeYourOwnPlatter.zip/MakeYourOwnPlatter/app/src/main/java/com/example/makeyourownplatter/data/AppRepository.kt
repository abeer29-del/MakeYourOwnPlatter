package com.example.makeyourownplatter.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/**
 * All reads and writes go through here.
 * Firebase Authentication handles logins; Cloud Firestore holds the data.
 */
class AppRepository {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private val users = db.collection("users")
    private val categories = db.collection("categories")
    private val menuItems = db.collection("menu_items")
    private val platters = db.collection("platters")
    private val orders = db.collection("orders")
    private val alerts = db.collection("alerts")
    private val counters = db.collection("counters")

    fun signOut() {
        auth.signOut()
    }

    // ---------- Numeric ids (Firestore ids are text, the app uses numbers) ----------

    /** Returns the next number for a counter, safely even with several phones at once. */
    private suspend fun nextId(counter: String): Long {
        val ref = counters.document(counter)
        return db.runTransaction { tx ->
            val next = tx.get(ref).getLong("next") ?: 1L
            tx.set(ref, mapOf("next" to next + 1L))
            next
        }.awaitResult()
    }

    // ---------- Account (User Module, UC-00) ----------

    suspend fun register(name: String, email: String, password: String): Result<UserEntity> = runCatching {
        require(name.isNotBlank()) { "Please enter your name." }
        require(password.length >= 6) { "Password must be at least 6 characters." }
        val cleanEmail = email.trim().lowercase()

        val uid = auth.createUserWithEmailAndPassword(cleanEmail, password)
            .awaitResult()
            .user?.uid ?: error("Could not create the account.")

        val userId = nextId("users")
        users.document(uid).set(
            mapOf(
                "userId" to userId,
                "name" to name.trim(),
                "email" to cleanEmail,
                "budgetLimit" to 0,
                "role" to "CUSTOMER"
            )
        ).awaitResult()

        UserEntity(userId = userId, uid = uid, name = name.trim(), email = cleanEmail, role = "CUSTOMER")
    }

    /** Logs in customers and admins. The role decides which screens they see. */
    suspend fun login(email: String, password: String): Result<UserEntity> = runCatching {
        val uid = auth.signInWithEmailAndPassword(email.trim().lowercase(), password)
            .awaitResult()
            .user?.uid ?: error("Login failed.")
        loadUser(uid)
    }.onFailure { auth.signOut() }

    private suspend fun loadUser(uid: String): UserEntity {
        val doc = users.document(uid).get().awaitResult()
        require(doc.exists()) { "This account has no profile yet. Please register again." }
        return UserEntity(
            userId = doc.getLong("userId") ?: 0L,
            uid = uid,
            name = doc.getString("name").orEmpty(),
            email = doc.getString("email").orEmpty(),
            budgetLimit = (doc.getLong("budgetLimit") ?: 0L).toInt(),
            role = doc.getString("role") ?: "CUSTOMER"
        )
    }

    // ---------- Budget + platter (Budget Management, UC-01 / UC-03) ----------

    /** Saves the budget on the active platter (creating one if needed). Returns the platter id. */
    suspend fun setBudget(user: UserEntity, budget: Int): Long {
        users.document(user.uid).update("budgetLimit", budget).awaitResult()
        val platter = getOrCreateActivePlatter(user)
        platters.document(platter.platterId.toString()).update("currentBudget", budget).awaitResult()
        return platter.platterId
    }

    suspend fun getOrCreateActivePlatter(user: UserEntity): PlatterEntity {
        val existing = platters
            .whereEqualTo("ownerUid", user.uid)
            .whereEqualTo("status", "ACTIVE")
            .limit(1)
            .get()
            .awaitResult()
        existing.documents.firstOrNull()?.let { return platterFrom(it) }

        val platterId = nextId("platters")
        val platter = PlatterEntity(platterId = platterId, userId = user.userId, ownerUid = user.uid)
        platters.document(platterId.toString()).set(
            mapOf(
                "platterId" to platter.platterId,
                "userId" to platter.userId,
                "ownerUid" to platter.ownerUid,
                "currentBudget" to platter.currentBudget,
                "status" to platter.status
            )
        ).awaitResult()
        return platter
    }

    fun observePlatter(platterId: Long): Flow<PlatterEntity?> =
        platters.document(platterId.toString()).observeDoc { platterFrom(it) }

    private fun platterFrom(doc: DocumentSnapshot): PlatterEntity = PlatterEntity(
        platterId = doc.id.toLong(),
        userId = doc.getLong("userId") ?: 0L,
        ownerUid = doc.getString("ownerUid").orEmpty(),
        currentBudget = (doc.getLong("currentBudget") ?: 0L).toInt(),
        status = doc.getString("status") ?: "ACTIVE"
    )

    // ---------- Platter items (Create Custom Platter, UC-02) ----------

    private fun platterItemsRef(platterId: Long) =
        platters.document(platterId.toString()).collection("items")

    /** Adds (+1) or removes (-1) one unit of an item. Quantity stays between 0 and 99. */
    suspend fun changeQuantity(platterId: Long, itemId: Long, delta: Int) {
        val ref = platterItemsRef(platterId).document(itemId.toString())
        db.runTransaction { tx ->
            val current = tx.get(ref).getLong("quantity") ?: 0L
            val next = (current + delta).coerceIn(0L, 99L)
            if (next == 0L) {
                tx.delete(ref)
            } else {
                tx.set(ref, mapOf("quantity" to next))
            }
            Unit
        }.awaitResult()
    }

    /** Replaces one expensive item with a cheaper one in two steps (UC-03). */
    suspend fun swapItems(platterId: Long, removeItemId: Long, addItemId: Long) {
        changeQuantity(platterId, removeItemId, -1)
        changeQuantity(platterId, addItemId, 1)
    }

    /** Live platter lines, joined with the menu so names, prices and emojis are current. */
    fun observeCart(platterId: Long): Flow<List<CartLine>> {
        val lines = platterItemsRef(platterId).observeList { doc ->
            PlatterItemEntity(
                platterId = platterId,
                itemId = doc.id.toLong(),
                quantity = (doc.getLong("quantity") ?: 0L).toInt()
            )
        }
        return combine(lines, observeAllItems()) { items, menu ->
            val byId = menu.associateBy { it.itemId }
            items.mapNotNull { line ->
                val item = byId[line.itemId] ?: return@mapNotNull null
                if (line.quantity <= 0) {
                    null
                } else {
                    CartLine(item.itemId, item.name, item.price, item.emoji, item.categoryId, line.quantity)
                }
            }.sortedBy { it.name }
        }
    }

    suspend fun currentCart(platterId: Long): List<CartLine> = observeCart(platterId).first()

    // ---------- Menu ----------

    fun observeCategories(): Flow<List<CategoryEntity>> =
        categories.observeList { doc ->
            CategoryEntity(categoryId = doc.id.toLong(), name = doc.getString("name").orEmpty())
        }.map { list -> list.sortedBy { it.categoryId } }

    fun observeAllItems(): Flow<List<FoodItemEntity>> =
        menuItems.observeList { itemFrom(it) }
            .map { list -> list.sortedWith(compareBy<FoodItemEntity> { it.categoryId }.thenBy { it.name }) }

    private fun itemFrom(doc: DocumentSnapshot): FoodItemEntity = FoodItemEntity(
        itemId = doc.id.toLong(),
        categoryId = doc.getLong("categoryId") ?: 0L,
        name = doc.getString("name").orEmpty(),
        description = doc.getString("description").orEmpty(),
        price = (doc.getLong("price") ?: 0L).toInt(),
        emoji = doc.getString("emoji").orEmpty(),
        isAvailable = doc.getBoolean("isAvailable") ?: true
    )

    private suspend fun writeMenuItem(item: FoodItemEntity) {
        menuItems.document(item.itemId.toString()).set(
            mapOf(
                "categoryId" to item.categoryId,
                "name" to item.name,
                "description" to item.description,
                "price" to item.price,
                "emoji" to item.emoji.ifBlank { "🍽️" },
                "isAvailable" to item.isAvailable
            )
        ).awaitResult()
    }

    /** Writes the starter menu once. Only an admin can write the menu, so the admin app calls this. */
    suspend fun seedMenuIfEmpty() {
        val existing = categories.limit(1).get().awaitResult()
        if (!existing.isEmpty) return

        for ((categoryName, items) in SeedData.menu) {
            val categoryId = nextId("categories")
            categories.document(categoryId.toString())
                .set(mapOf("categoryId" to categoryId, "name" to categoryName))
                .awaitResult()
            for (item in items) {
                writeMenuItem(
                    FoodItemEntity(
                        itemId = nextId("menu_items"),
                        categoryId = categoryId,
                        name = item.name,
                        description = item.description,
                        price = item.price,
                        emoji = item.emoji
                    )
                )
            }
        }
    }

    // ---------- Order placement (UC-04 + operator alert) ----------

    /**
     * Saves the order, its item snapshot, a PENDING status and the operator alert
     * in one batch. Totals are recalculated from the menu, not trusted from the screen.
     */
    suspend fun placeOrder(user: UserEntity, platterId: Long): Result<Long> = runCatching {
        val lines = currentCart(platterId)
        require(lines.isNotEmpty()) { "Your platter is empty. Add some items first." }

        val platterDoc = platters.document(platterId.toString()).get().awaitResult()
        val budget = (platterDoc.getLong("currentBudget") ?: 0L).toInt()
        val total = lines.sumOf { it.price * it.quantity }
        val itemCount = lines.sumOf { it.quantity }

        val orderId = nextId("orders")
        val alertId = nextId("alerts")
        val now = System.currentTimeMillis()

        val batch = db.batch()
        batch.set(
            orders.document(orderId.toString()),
            mapOf(
                "userId" to user.userId,
                "ownerUid" to user.uid,
                "customerName" to user.name,
                "customerEmail" to user.email,
                "platterId" to platterId,
                "budget" to budget,
                "totalAmount" to total,
                "orderStatus" to "PENDING",
                "orderDate" to now,
                "items" to lines.map { line ->
                    mapOf(
                        "itemId" to line.itemId,
                        "itemName" to line.name,
                        "unitPrice" to line.price,
                        "quantity" to line.quantity
                    )
                }
            )
        )
        batch.set(
            alerts.document(alertId.toString()),
            mapOf(
                "alertId" to alertId,
                "orderId" to orderId,
                "message" to "New order #$orderId: $itemCount item(s), Rs. $total",
                "timestamp" to now,
                "isRead" to false
            )
        )
        batch.update(platters.document(platterId.toString()), "status", "ORDERED")
        batch.commit().awaitResult()

        orderId
    }

    // ---------- Admin: orders and alerts ----------

    fun observeOrders(): Flow<List<OrderEntity>> =
        orders.observeList { doc ->
            OrderEntity(
                orderId = doc.id.toLong(),
                userId = doc.getLong("userId") ?: 0L,
                customerName = doc.getString("customerName").orEmpty(),
                customerEmail = doc.getString("customerEmail").orEmpty(),
                platterId = doc.getLong("platterId") ?: 0L,
                budget = (doc.getLong("budget") ?: 0L).toInt(),
                totalAmount = (doc.getLong("totalAmount") ?: 0L).toInt(),
                orderStatus = doc.getString("orderStatus") ?: "PENDING",
                orderDate = doc.getLong("orderDate") ?: 0L,
                items = orderItemsFrom(doc)
            )
        }.map { list -> list.sortedByDescending { it.orderDate } }

    private fun orderItemsFrom(doc: DocumentSnapshot): List<OrderItemEntity> {
        val raw = doc.get("items") as? List<*> ?: return emptyList()
        return raw.mapNotNull { entry ->
            val map = entry as? Map<*, *> ?: return@mapNotNull null
            OrderItemEntity(
                orderId = doc.id.toLong(),
                itemId = (map["itemId"] as? Number)?.toLong() ?: 0L,
                itemName = map["itemName"] as? String ?: "",
                unitPrice = (map["unitPrice"] as? Number)?.toInt() ?: 0,
                quantity = (map["quantity"] as? Number)?.toInt() ?: 0
            )
        }
    }

    suspend fun setOrderStatus(orderId: Long, status: String) {
        orders.document(orderId.toString()).update("orderStatus", status).awaitResult()
    }

    fun observeAlerts(): Flow<List<AlertEntity>> =
        alerts.observeList { doc ->
            AlertEntity(
                alertId = doc.id.toLong(),
                orderId = doc.getLong("orderId") ?: 0L,
                message = doc.getString("message").orEmpty(),
                timestamp = doc.getLong("timestamp") ?: 0L,
                isRead = doc.getBoolean("isRead") ?: false
            )
        }.map { list -> list.sortedByDescending { it.timestamp } }

    suspend fun markAlertRead(alertId: Long) {
        alerts.document(alertId.toString()).update("isRead", true).awaitResult()
    }

    suspend fun markAllAlertsRead() {
        val unread = alerts.whereEqualTo("isRead", false).get().awaitResult()
        if (unread.isEmpty) return
        val batch = db.batch()
        unread.documents.forEach { batch.update(it.reference, "isRead", true) }
        batch.commit().awaitResult()
    }

    // ---------- Admin: menu management (UC-06) ----------

    suspend fun addMenuItem(categoryId: Long, name: String, description: String, price: Int, emoji: String) {
        require(name.isNotBlank()) { "Item name is required." }
        require(price > 0) { "Price must be more than 0." }
        writeMenuItem(
            FoodItemEntity(
                itemId = nextId("menu_items"),
                categoryId = categoryId,
                name = name.trim(),
                description = description.trim(),
                price = price,
                emoji = emoji
            )
        )
    }

    suspend fun updateMenuItem(item: FoodItemEntity) {
        require(item.price > 0) { "Price must be more than 0." }
        writeMenuItem(item)
    }
}
